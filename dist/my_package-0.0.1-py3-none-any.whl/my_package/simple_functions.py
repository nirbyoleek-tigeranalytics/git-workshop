# Custom python functions


def double_number(a):
    return a + a


def square_number(a):
    return a * a
